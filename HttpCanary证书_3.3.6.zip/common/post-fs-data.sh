#!/system/bin/sh
MODDIR=${0%/*}
#此脚本以post-fs-data模式执行
