#!/system/bin/sh
MODDIR=${0%/*}
#此脚本会在设备启动时执行
sleep 20
touch /data/data/com.guoshi.httpcanary/cache/HttpCanary.jks
rm -f $MODDIR/service.sh