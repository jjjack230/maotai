#true或false

#是否安装模块后自动关闭
SKIPMOUNT=false

#是否加载system.prop文件
PROPFILE=false

#是否加载post-fs-data.sh脚本
POSTFSDATA=false

#是否加载service.sh脚本
LATESTARTSERVICE=true

#添加文件
ui_print "- 正在添加文件"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

#设置权限
set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}